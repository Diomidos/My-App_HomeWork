import React from "react";
import CountersList from "./Components/countersList";

const App = () => {
  return <CountersList />;
};
export default App;
